package com.todo.fursa.util

interface IListCallback {

    fun onShowTodoDetails(todoId: Long)

}