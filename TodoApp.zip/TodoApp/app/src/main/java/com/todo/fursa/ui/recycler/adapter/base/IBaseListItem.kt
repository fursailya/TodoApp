package com.todo.fursa.ui.recycler.adapter.base

interface IBaseListItem {
    fun getLayoutId(): Int
}