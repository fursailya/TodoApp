package com.todo.fursa.ui.model

data class Note(
        var title: String?,
        var description: String?,
        var priorityDrawable: Int,
        var priorityText: String?,
        var remindTime: String?)
